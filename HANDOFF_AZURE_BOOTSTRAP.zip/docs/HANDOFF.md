# OptiSweepAI Ingestion Handoff

Use this as the first-stop inventory for a new owner. The repo has three active tracks: the ingestion pipelines, the shared publish path, and the newer Brain service work.

## Read These First

1. `AGENT_AZURE_HANDOFF.md` - step-by-step new-owner Azure recreation for an agent.
2. `HANDOFF_AZURE_BOOTSTRAP.zip` - curated portable publish bundle and Cosmos shape docs at repo root.
3. `README.md` - repo start page and current run commands.
4. `docs/architecture.md` - current architecture and why the publish path works this way.
5. `orchestration/README.md` - easiest end-to-end entrypoint for inbox/watch/SharePoint flows.
6. `shared_pipeline_stages/README.md` - Shared Stages 6.5-11, including cumulative Cosmos publish.
7. `app_handoff_package/README.md` - Phase 0 app-side Cosmos loading, scoring, and gate phrase contract.
8. `brain/README.md` and `brain/DESIGN_RATIONALE.md` - source-agnostic Brain schemas, service boundary, and migrated design rationale.

## Active Areas

| Area | Status | Purpose |
| --- | --- | --- |
| `orchestration/` | Active | LangGraph entrypoints over local inbox and optional SharePoint intake. |
| `incidenceknowledgeingestion/` | Active | Incident PDF evidence Stages 1-6 and per-source Stage 8 links. |
| `operationalknowledgeingestion/` | Active | Manual/training/support-guide Stages 1-8. |
| `shared_pipeline_stages/` | Active | Shared runbook pool, merge, playbooks, validation, embeddings, cumulative Cosmos publish. |
| `app_handoff_package/` | Active docs only | App implementation contract for Cosmos records, retrieval, and gate phrases. |
| `brain/`, `brain_service/`, `http_server/`, `mcp_server/`, `providers/` | Active | Source-agnostic Brain records, service logic, HTTP/MCP surfaces, and provider wrappers. |
| `connectors/` | Active probes | Salesforce and Microsoft Graph dev probes/adapters. |
| `data/inbox/` | Active drop zone | Local files to ingest; real source files are ignored after placement. |
| `data/output/` | Active handoff output | Assembled SME review and Cosmos publish outputs. |
| `docs/ontology/` and `stage_prompts/` | Active contracts | Taxonomy, prompt, and ontology guidance consumed by stages. |

## Generated Or Review Outputs

These are useful for audit and SME review, but they are not the canonical source of code behavior:

- `incidenceknowledgeingestion/data/output/`
- `operationalknowledgeingestion/data/output/`
- `shared_pipeline_stages/data/output/`
- `sme_review_runbooks/`
- `data/output/baseline_publishes/`
- `brain/data/local/`

Keep these outputs for tests, replay, SME review, Azure bootstrap, and app handoff. Do not delete `data/output/` or `brain/data/local/` during ownership transfer. `HANDOFF_DATA_INVENTORY.md` lists retained output trees that may need separate transfer if the root zip is not enough.

## Azure And Phase 0 Handoff

The previous owner's Azure resources are not the target. Recreate resources in
the new owner's subscription using `AGENT_AZURE_HANDOFF.md`, then upload the
retained `data/output/cosmos_publish/` bundle to the new Stage 11 app-publish
containers.

The OptiSweep Phase 0 app is a separate codebase. From this repo it consumes:

- Stage 11 Cosmos containers for runbooks, playbooks, embeddings, relationship
  shards, operational context, source artifacts, canonical images, and gate
  phrases.
- `PUBLISH_VERSION_ID` from `data/output/cosmos_publish/publish_manifest.json`.
- Blob image URIs produced during Stage 11 publish.
- Optional `BRAIN_HTTP_BASE_URL` if the Brain HTTP API is redeployed under the
  new subscription.

Authoritative app integration docs live under `app_handoff_package/`. The app
retrieves/scores/renders; this repo ingests/publishes/serves Brain contracts.

## What To Ignore

- Top-level scratch files, temporary checkout folders, and root-level PDF/PPTX dumps are not handoff material.
- `app_handoff_package/sample_data/` and its generator/smoke scripts were removed; the app must load Cosmos, not local sample files.
- Historical design notes under `docs/design_decisions/` may explain why decisions were made, but current behavior should be verified against `docs/architecture.md`, area READMEs, and code. The retired `newdesigndoc/` content was migrated into `brain/DESIGN_RATIONALE.md`, `brain/README.md`, `docs/architecture.md`, and this handoff.

## Main Entrypoints

```powershell
# Watch local inbox and publish to Cosmos
python orchestration/scripts/watch_inbox.py --publish-to-cosmos

# Run one source through ingestion and shared publish
python orchestration/scripts/run_ingestion_agent.py `
  --source "data/inbox/incidents/Case 228086 Data.pdf" `
  --with-publish `
  --publish-to-cosmos `
  --publish-scope all

# Assemble current outputs without new ingest
python orchestration/scripts/assemble_output.py
```

Use source-specific scripts only when debugging a stage directly:

- `incidenceknowledgeingestion/scripts/extract_incident_knowledge.py`
- `operationalknowledgeingestion/scripts/extract_operational_knowledge.py`
- `shared_pipeline_stages/scripts/stage11_publish_cosmos.py`

## Cleanup Notes

During handoff cleanup, deprecated app-local corpus samples and temporary checkout artifacts had already been removed. The former `newdesigndoc/` tree was migrated into active Brain and handoff docs, then deleted.
