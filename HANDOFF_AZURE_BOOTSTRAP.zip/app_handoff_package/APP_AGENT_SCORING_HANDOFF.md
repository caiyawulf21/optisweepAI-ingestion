# App agent handoff — entry-scoped playbook scoring (Jul 13, 2026)

**Audience:** OptiSweep AI app-repo coding agent  
**Ingestion repo:** `optisweepAI-ingestion`  
**Read with:** `CURSOR_PROMPT.md`, `COSMOS_DATA_MAP.md`, `retrieval/ALGORITHMS.md`, `retrieval/local_hybrid_retriever.py`

---

## Point the app here

| Setting | Value |
|---------|-------|
| `PUBLISH_VERSION_ID` | `publish_20260713_194435_68eafe74` |
| Manifest | `shared_pipeline_stages/data/output/shared/stage_11_cosmos_publish/publish_manifest.json` |
| Embedding model (query + docs) | `text-embedding-3-small` (must match Cosmos `embedding_model`) |
| Cosmos | Already published (`Uploaded to Cosmos: True`) — reload index for this version |

Containers (unchanged env names): `COSMOS_CONTAINER_PLAYBOOKS_A` / `_B`, `COSMOS_CONTAINER_RUNBOOKS`, `COSMOS_CONTAINER_RELATIONSHIP_LINKS`, etc.

Playbook `embedded_text` in this version is **entry-scoped only** (title + `observed_entry_symptoms` + `support_user_language_examples`). Do not expect fat narrative blobs.

---

## What ingestion changed

1. **Stage 8 embed text** (`shared_pipeline_stages/stage_8/playbook_retrieval.py` → `build_playbook_retrieval_text`)  
   Playbook vectors = title + entry symptoms + user-language examples. Dropped: summary, systems list, node/recovery language.

2. **Stage 5 prompts** (A + B)  
   Require short operator speech in `support_user_language_examples` (e.g. `"AGVs stopped"`, `"robots stopped"`, `"nothing is moving"`).

3. **Patched + rebuilt pilot cards**  
   Case 228086 stoppage candidates got those phrases; Stage 8 → 9 → 10 → 11 republished.

4. **Handoff scoring reference** (`retrieval/local_hybrid_retriever.py`, `ALGORITHMS.md`)  
   Symptom boost now dampens single-phrase exact matches (see critique below). **Port this formula into the app.**

---

## Test results (`"agvs stopped"`, real Azure embeddings, post-republish)

Raw components (before dampening fix) on live Stage 10 vectors:

| Variant | Top playbook | cosine | jaccard | raw best-phrase | phrase coverage |
|---------|--------------|--------|---------|-----------------|-----------------|
| A | `playbook_incident_228086_site_wide_motion_stoppage_service_recovery` | ~0.51 | ~0.04 | **1.00** (exact example) | ~0.31 |
| A | 228723 pairing | ~0.41 | ~0.02 | ~0.08 | ~0.12 |
| B | `playbook_incident_228086_site_stoppage_optisweep_recovery` | ~0.49 | ~0.04 | **1.00** | ~0.35 |
| B | 228723 / WCS | ≤0.31 hybrid | — | 0 | 0 |

**Before ingestion change:** sparse query scored ~0.01 (fat doc + missing operator phrases).  
**After:** cosine ~0.5; exact example phrase hit; stoppage clearly ranks above pairing.

With **damped** symptom formula (`0.70 * best + 0.30 * coverage`), re-measured:

| Variant | Top | combined | cosine | symptom | coverage |
|---------|-----|----------|--------|---------|----------|
| A | 228086 stoppage | **0.79** | 0.51 | 0.79 | 0.31 |
| A | 228723 pairing | 0.30 | 0.41 | 0.09 | 0.13 |
| B | 228086 stoppage | **0.81** | 0.49 | 0.81 | 0.35 |
| B | 228723 | 0.31 | 0.45 | 0.00 | 0.00 |

Stoppage clears pin (≥0.55) and high-confidence (≥0.75) with coverage ≥0.25. Pairing stays candidates/ask — not pin. Combined is **high, not 1.0**.

Threshold philosophy (do not change to fit old 0.01):

| Band | Behavior |
|------|----------|
| `< ~0.35` | Ask symptoms / weak related |
| `~0.35–0.55` | Candidates only; user picks |
| `≥ 0.55` **and** coverage ≥ ~0.25 | Auto-pin allowed |
| `≥ 0.75` + coverage | High-confidence auto-pin |

---

## Product critique (implement in app)

> Confidence should **not** be exactly 1.0 when the query only matches one entry phrase. High is fine; perfect is wrong.

**Required app scoring behavior**

```python
best_phrase = max Jaccard(query, each of symptoms + examples)
coverage    = (# phrases with any token overlap) / (total phrases)
symptom     = 0.70 * best_phrase + 0.30 * coverage
rank_score  = max(0.7 * cosine + 0.3 * jaccard, symptom)

auto_pin = rank_score >= 0.55 and coverage >= 0.25   # or user picks
# do NOT: lower thresholds, relative-pin best-of-bad, or score = 0.5 + 0.5 * score
```

**Trace tab must show separately:** `cosine`, `jaccard`, `symptom`, `coverage`, `combined` — so SMEs see that a single exact phrase match is high (~0.75–0.85) but not absolute certainty.

Pin confidence ≠ retrieval rank: sparse speech can improve ranking and still fail the pin gate until coverage / user confirmation is enough.

---

## App work checklist

1. Set `PUBLISH_VERSION_ID=publish_20260713_194435_68eafe74` and reload Cosmos embedding index.
2. Port damped `symptom_overlap_score` + `entry_phrase_coverage` from `retrieval/local_hybrid_retriever.py`.
3. Wire pin gate: hybrid/rank ≥ 0.55 **and** coverage ≥ 0.25 (or explicit candidate pick).
4. Expose score breakdown in Trace.
5. Smoke: `"AGVs stopped"` → 228086 stoppage playbook (A and B); `"zone can't pair"` → 228723; Trace shows combined ≈ **0.79–0.81** (not 1.0) for this sparse query.
6. Confirm query embed deployment = `text-embedding-3-small`.

---

## Out of scope for this handoff

- Do not re-lower pin thresholds.
- Do not read `sample_data/` as runtime corpus (deprecated).
- Do not add Azure AI Search.
- Full narrative / `playbook_*_full` dual vectors — later; not required for Jul demo.
