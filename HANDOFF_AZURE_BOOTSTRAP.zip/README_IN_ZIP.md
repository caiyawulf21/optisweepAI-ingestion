# HANDOFF_AZURE_BOOTSTRAP.zip

Portable Azure bootstrap package for a new OptiSweep ingestion owner.

This package contains curated essentials rather than every generated tree in the repository. The complete current Stage 11 app-publish bundle from `data/output/cosmos_publish/` is included because it is the fastest way to recreate the Phase 0 app Cosmos corpus in a new Azure account. Larger retained local data, especially `brain/data/local/`, remains in the repo and is inventoried in `HANDOFF_DATA_INVENTORY.md` for separate transfer when needed.

Use this package with the repo-root `AGENT_AZURE_HANDOFF.md`.

## Contents

- `data/output/cosmos_publish/`: current Stage 11 publish bundle, manifest, upload report, gate/smoke reports, relationship shards, runbooks, playbooks, embeddings, canonical image metadata, operational context, source artifacts, and gate phrase table.
- `app_handoff_package/`: Phase 0 app Cosmos consumption, retrieval/scoring, feature flag, and gate phrase contracts.
- `docs/architecture.md` and `docs/HANDOFF.md`: current repo architecture and handoff read order.
- `AGENT_AZURE_HANDOFF.md`: step-by-step new-owner Azure recreation instructions for an agent.
- `.env.example`: env var names only, with no real secrets.
- `brain/README.md` and `brain/DESIGN_RATIONALE.md`: Brain contract overview and migrated design rationale.
- `brain/schemas/`: Brain record shapes.
- `providers/azure_cosmos_config.py` and `providers/scripts/*cosmos*.py`: Brain Cosmos container definitions and sync entrypoints.
- `shared_pipeline_stages/stage_11/container_config.py`: Stage 11 app-publish container defaults.
- `HANDOFF_DATA_INVENTORY.md`: full generated-output inventory from the source repo.

## Recreate Cosmos From This Package

1. Create new Azure resources in the new owner's subscription. Do not reuse the previous owner's account.
2. Fill `.env` in the repo from `.env.example` using new-owner secrets and resource endpoints.
3. Create Stage 11 app-publish Cosmos containers with partition key `/publish_version_id`.
4. Upload `data/output/cosmos_publish/publish_bundle/` with:

```powershell
python orchestration/scripts/publish_cosmos_from_output.py --publish-scope all
```

5. Provision Brain containers with partition key `/_partition_key` using:

```powershell
python -m providers.scripts.provision_brain_cosmos_containers
```

6. If the full repo is available, sync the retained Brain corpus from `brain/data/local/`:

```powershell
python -m providers.scripts.sync_local_brain_to_cosmos --dry-run
python -m providers.scripts.sync_local_brain_to_cosmos
```

7. Point the separate Phase 0 app repo at the new Cosmos endpoint, containers, Blob settings, embedding deployment, and `PUBLISH_VERSION_ID` from `data/output/cosmos_publish/publish_manifest.json`.
